# -*- coding: utf-8 -*-

import os.path

# -----------------------------------------------------------------------------
# CONSTANTS:
# -----------------------------------------------------------------------------
HERE    = os.path.dirname(__file__)
TOP     = os.path.join(HERE, "..")
TOPA    = os.path.abspath(TOP)
