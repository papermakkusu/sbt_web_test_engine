Noteworthy in Version 1.2.4
==============================================================================


Diagnostics: Start Debugger on Error
-------------------------------------------------------------------------------

:Since: behave 1.2.4a1

See also :ref:`debug-on-error` .

